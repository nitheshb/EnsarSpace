import CoursedetailsPage from './CoursedetailsPage'

export const generated = (args) => {
  return <CoursedetailsPage  {...args} />
}

export default { title: 'Pages/CoursedetailsPage' }
